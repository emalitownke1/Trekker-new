<?php
// Do NOT expose this file or variables to frontend
$apiUrl = "https://api.smartpaypesa.com/v1/transactionstatus/";
$apiKey = "dac85c2c4078a202ef1c2edf87bcd1dba08bb3867f14de3366efd5722c6e9d33"; // Keep this secret
